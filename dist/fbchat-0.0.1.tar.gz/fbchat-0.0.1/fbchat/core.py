# -*- coding: UTF-8 -*-


"""
Core components for fbchat
"""


import requests
